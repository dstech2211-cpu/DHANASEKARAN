"""
AI IoT Sensor Data Analyst — starter project
Run in Google Colab or locally:
  pip install pandas numpy matplotlib
  python analyze_sensors.py
This dataset is simulated for education, not real environmental monitoring.
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "sensor_data_raw.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

# 1) Load data
df = pd.read_csv(DATA)
print("Raw rows:", len(df))
print(df.head())

# 2) Clean data
df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
before = len(df)
df = df.drop_duplicates()
duplicates_removed = before - len(df)

numeric_cols = ["temperature_c", "humidity_pct", "light_lux"]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

missing_before = df[numeric_cols].isna().sum().to_dict()
# Use median imputation for this demonstration; document that it can hide real sensor faults.
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

# Physical plausibility checks; ranges are broad sanity checks, not universal safety limits.
valid = (
    df["temperature_c"].between(-20, 80)
    & df["humidity_pct"].between(0, 100)
    & df["light_lux"].between(0, 200000)
)
df["physical_range_valid"] = valid

# 3) Flag statistical anomalies using IQR (computed separately per column)
def iqr_flag(series):
    q1, q3 = series.quantile([0.25, 0.75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return (series < lower) | (series > upper), lower, upper

for col in numeric_cols:
    flags, lower, upper = iqr_flag(df[col])
    df[f"{col}_anomaly"] = flags
    print(f"{col}: IQR bounds {lower:.2f} to {upper:.2f}; flagged {int(flags.sum())}")

anomaly_cols = [f"{c}_anomaly" for c in numeric_cols]
df["any_statistical_anomaly"] = df[anomaly_cols].any(axis=1)

# 4) Summary statistics
summary = df[numeric_cols].describe().round(2)
summary.to_csv(OUT / "summary_statistics.csv")
df.to_csv(OUT / "analyzed_sensor_data.csv", index=False)

# 5) Charts
for col, ylabel, title, filename in [
    ("temperature_c", "Temperature (°C)", "Temperature over time", "temperature_chart.png"),
    ("humidity_pct", "Humidity (%)", "Humidity over time", "humidity_chart.png"),
    ("light_lux", "Light intensity (lux)", "Light intensity over time", "light_chart.png"),
]:
    plt.figure(figsize=(10, 4))
    plt.plot(df["timestamp"], df[col], marker=".", linewidth=1)
    marked = df[df[f"{col}_anomaly"]]
    plt.scatter(marked["timestamp"], marked[col], marker="x", s=70)
    plt.title(title)
    plt.xlabel("Timestamp")
    plt.ylabel(ylabel)
    plt.xticks(rotation=35, ha="right")
    plt.tight_layout()
    plt.savefig(OUT / filename, dpi=160)
    plt.close()

# 6) Create concise text report
report = [
    "AI IoT SENSOR DATA ANALYST — AUTOMATED SUMMARY",
    "=" * 48,
    f"Rows after duplicate removal: {len(df)}",
    f"Duplicate rows removed: {duplicates_removed}",
    f"Missing values before imputation: {missing_before}",
    "",
    "Descriptive statistics:",
    summary.to_string(),
    "",
    f"Rows flagged by IQR in any sensor: {int(df['any_statistical_anomaly'].sum())}",
    "Anomaly flags indicate unusual values relative to this sample, not proof of a faulty sensor.",
    "All readings are simulated. Confirm any real-world concern with calibrated instruments and context.",
]
(OUT / "analysis_report.txt").write_text("\n".join(report), encoding="utf-8")
print("\n".join(report))
print(f"\nFiles saved to: {OUT}")
