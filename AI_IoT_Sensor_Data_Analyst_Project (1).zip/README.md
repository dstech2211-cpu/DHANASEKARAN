# AI IoT Sensor Data Analyst — ECE Capstone 14

## Project goal
Analyze temperature, humidity, and light readings; clean the dataset; flag statistical anomalies; verify findings with Python; create charts and an automated report.

**Important:** the included data is simulated for a student demonstration. Statistical outliers are not automatically sensor faults or safety violations.

## Step-by-step setup (Google Colab)
1. Open Google Colab: https://colab.research.google.com/
2. Choose **New notebook**.
3. Upload `data/sensor_data_raw.csv` to the Colab session (left sidebar → Files → Upload).
4. Copy the code from `analyze_sensors.py` into a notebook cell, changing the data path to `/content/sensor_data_raw.csv` and output path to `/content/outputs`, or run the script locally.
5. Run all cells. Inspect printed summary statistics and the `outputs` folder.
6. Download the generated charts and CSVs for your report.
7. Ask an AI assistant to explain the summary and possible anomalies, but verify every numeric claim against Python output.
8. Add your own name, register number, department, guide, and institution to the report/presentation.

## Local run
Install Python 3.10+ then run:
`pip install pandas numpy matplotlib`
Then run `python analyze_sensors.py` from this project folder.

## What the code does
- Removes exact duplicate rows.
- Converts timestamps and numeric columns.
- Fills missing numeric values with each column's median (a simple demonstration choice; other approaches may be better).
- Uses IQR bounds to flag statistical outliers.
- Creates summary statistics, analyzed CSV, three charts, and a text report.

## Deliverables checklist
- [x] Dataset (raw sample data included)
- [x] Analysis script
- [x] Charts generated when script is run
- [x] Prompt library
- [x] Error log template
- [x] Verification report template
- [x] Presentation outline
- [ ] Run script and insert your actual outputs/screenshots
- [ ] Compare with authoritative sensor/environment references relevant to your location and use case
- [ ] Demonstrate one reporting automation step
- [ ] Personalize final report and slides

## Limitations and responsible use
- Sample readings are simulated and not from physical sensors.
- IQR can miss anomalies or flag normal events; context matters.
- Median imputation changes the data and can hide a real fault.
- Reference ranges depend on sensor calibration, location, application, and authoritative source.
- Do not upload personal or sensitive data to AI tools without permission.
- Keep the raw data and document every cleaning decision.
