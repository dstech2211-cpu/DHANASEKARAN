# Presentation Outline (7 slides)

## Slide 1 — Title
AI-Based IoT Sensor Data Analysis, Anomaly Detection and Automated Reporting
Student name, register number, ECE department, institution, guide.

## Slide 2 — Problem and objectives
IoT devices generate many readings; manual review is slow. Objectives: clean data, identify trends/outliers, verify calculations, and automate a report.

## Slide 3 — Dataset and workflow
100 simulated readings of timestamp, temperature (°C), humidity (%), and light (lux). Workflow: CSV → cleaning → statistics/IQR → verification → charts/report.

## Slide 4 — Methods and tools
Python, Pandas, NumPy, Matplotlib, ChatGPT for interpretation. Explain duplicate removal, median imputation, IQR outlier rule.

## Slide 5 — Results
Insert your generated temperature, humidity, and light charts. Report exact mean/min/max and the number of rows flagged from your actual program output.

## Slide 6 — Verification, AI mistakes, and limitations
Compare AI claims against Python/Sheets. Discuss simulated data, context-dependent ranges, possible false positives/negatives, and median imputation limitations.

## Slide 7 — Recommendations and conclusion
Give evidence-based recommendations, describe the weekly report automation, privacy safeguards, and future work using a real calibrated sensor.
