# Verification Report Template

## 1. Dataset
- File:
- Source: Simulated educational data / actual sensor data (choose one)
- Number of rows before cleaning:
- Number of rows after duplicate removal:

## 2. Cleaning verification
- Duplicate rows removed:
- Missing values by column:
- Imputation or removal method:
- Why this method was chosen:
- Any physical-range checks:

## 3. Numerical verification
For each sensor, record Python and manual/Sheets results.

| Metric | Python result | Independent calculation | Match? |
|---|---:|---:|---|
| Temperature mean | | | |
| Temperature median | | | |
| Humidity mean | | | |
| Light mean | | | |
| IQR bounds | | | |

## 4. Anomaly verification
For every flagged row, inspect raw data, timestamps, surrounding readings, instrument details, and plausible operating conditions. An anomaly flag is a prompt for investigation, not proof of failure.

## 5. External references
- Source organization:
- Page/document title:
- What exact claim it supports:
- Date accessed:
- Link:

## 6. Conclusion
Summarize what was verified, what remains uncertain, and what additional sensor readings or calibration would be needed.
