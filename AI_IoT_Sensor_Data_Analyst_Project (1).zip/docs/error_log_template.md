# AI and Data Error Log (fill this in during your run)

| ID | AI/tool claim or issue | Independent check | Result | Correction/action |
|---|---|---|---|---|
| E01 | Example: AI reports the row count incorrectly | `len(df)` after duplicate removal | Compare actual output | Record the corrected count |
| E02 | Example: AI labels an outlier as a confirmed sensor failure | Review raw value, context, calibration, and repeat reading | Outlier alone does not prove failure | Reword as “requires investigation” |
| E03 | Example: AI gives an unsupported environmental limit | Open the cited official source and check its scope | Accept only if source supports the claim | Replace or remove unsupported range |

Only report errors you actually observed. The rows above are examples, not claims that the AI made these errors in your run.
