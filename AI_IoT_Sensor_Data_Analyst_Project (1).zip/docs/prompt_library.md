# Prompt Library — AI IoT Sensor Data Analyst

## Prompt 1: Data quality review
Inspect the column names, data types, row count, missing values, duplicates, and impossible values in this sensor dataset. Do not modify data silently. List each proposed cleaning action and its reason.

## Prompt 2: Trend analysis
Using only the supplied verified summary statistics and chart descriptions, explain the main temperature, humidity, and light trends. Separate observations from hypotheses. Do not invent measurements.

## Prompt 3: Anomaly interpretation
Review these rows flagged by the IQR method. For each, state the sensor, value, statistical threshold, possible explanations, and a safe verification step. Explain that an outlier is not automatically a sensor failure.

## Prompt 4: Verify calculations
Recalculate the mean, median, minimum, maximum, and IQR bounds from the supplied CSV or Python output. Show the formula and identify any mismatch. If you cannot calculate from the data provided, say so.

## Prompt 5: Reference research
Find authoritative references for plausible temperature, relative humidity, and illuminance ranges for the stated application and location. Give the source organization, title, date, and link. Do not call a broad physical range a safety standard.

## Prompt 6: Recommendations
Give three practical recommendations tied to observed results. Label each as high/medium/low confidence and state what additional measurement would confirm it.

## Prompt 7: Short report
Write a one-page student report with objective, dataset, cleaning steps, method, verified results, limitations, and conclusion. Use only the supplied results and clearly label simulated data.

## Prompt 8: Weekly automation
Create a Python function that reads a new weekly CSV, validates required columns, calculates summary statistics, flags IQR outliers, and writes a dated report. Do not send data to an external AI service automatically.
